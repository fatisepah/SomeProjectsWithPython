date=input()
year=date[0:2]
month=date[2:4]
line1="saal:"+year
line2="maah:"+month
print(line1)
print(line2)
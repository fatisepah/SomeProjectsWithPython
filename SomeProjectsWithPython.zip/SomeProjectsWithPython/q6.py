in1=int(input())

sum=0
for i in range(in1):
    num=int(input())
    sum+=num

print(sum)